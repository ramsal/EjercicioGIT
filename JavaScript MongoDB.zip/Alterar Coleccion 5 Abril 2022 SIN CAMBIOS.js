
/* Parte 1 */

mongo

use concesionario

db.coches.updateMany( {},
    {$set: {"ID_Operacion":1}}
)

for (let index = 0; index < db.coches.count(); index++) {
    var random = Math.floor(Math.random()*100);
    db.coches.updateOne(
        {"ID_Operacion":1},
        {$set:{"ID_Operacion":random}}
        )
}

db.coches.find().pretty()


db.clientes.updateMany( {},
    {$set: {"ID_Operacion":1}}
)

for (let index = 0; index < db.clientes.count(); index++) {
    var random = Math.floor(Math.random()*100);
    db.clientes.updateOne(
        {"ID_Operacion":1},
        {$set:{"ID_Operacion":random}}
        )
}

db.clientes.find().pretty()

/* Parte 2 */

db.coches.updateMany({$mul: {Precio: 0.9}});

/* Aquí me da una excepción, y es que se trata de un valor "undefined" que no pudo convertirse en objeto
Hasta aquí he llegado, lo he luchado, pero no encuentro qué hacer */